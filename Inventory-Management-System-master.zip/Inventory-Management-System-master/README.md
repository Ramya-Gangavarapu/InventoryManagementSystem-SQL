# Inventory-Management-System
**Database Management System Project on the Inventory Management System using SQL**

I have Shared the report file of my Database management System project which i have implemented using Structured Query Language(SQL). This file also contains an ER- Diagram for better understanding.

**How To Implement:**

Download SQL Command Line in your System.
Run all the Create Table Commands one by one.(Make sure you have removed all the serial numbering(1,2,3..)before copying the command).
After creating the Table, insert the values in it by using the commands mentioned in the pdf file.
</BR>Your Project is Ready!!


</BR> Licensed under [MIT License](LICENSE).


